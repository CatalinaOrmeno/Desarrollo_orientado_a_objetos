package Modelo;

/**
 *
 * @author Catalina
 */
public class Peluche {
    
}
