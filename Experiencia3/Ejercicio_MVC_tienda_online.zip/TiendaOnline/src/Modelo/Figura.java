package Modelo;

/**
 *
 * @author Catalina
 */
public class Figura {
    
}
