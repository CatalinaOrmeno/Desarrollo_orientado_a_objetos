package Modelo;

import java.util.Date;

/**
 *
 * @author Catalina
 */
public class Peluche extends Producto{
    private Date fecha_lanzamiento;
    private boolean relleno_natural;

    public Peluche() {
    }

    public Peluche(Date fecha_lanzamiento, boolean relleno_natural, String identificador, String nombre, String descripcion, int precio) {
        super(identificador, nombre, descripcion, precio);
        this.fecha_lanzamiento = fecha_lanzamiento;
        this.relleno_natural = relleno_natural;
    }

    public Date getFecha_lanzamiento() {
        return fecha_lanzamiento;
    }

    public void setFecha_lanzamiento(Date fecha_lanzamiento) {
        this.fecha_lanzamiento = fecha_lanzamiento;
    }

    public boolean isRelleno_natural() {
        return relleno_natural;
    }

    public void setRelleno_natural(boolean relleno_natural) {
        this.relleno_natural = relleno_natural;
    }

    @Override
    public String toString() {
        return super.toString() + "Peluche{" + "fecha_lanzamiento=" + fecha_lanzamiento + ", relleno_natural=" + relleno_natural + '}';
    }
}
