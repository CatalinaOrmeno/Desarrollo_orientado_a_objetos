package Modelo;

/**
 *
 * @author Catalina
 */
public abstract class Producto {
    protected String identificador,nombre,descripcion;
    protected double precio;

    public Producto() {
    }

    public Producto(String identificador, String nombre, String descripcion, double precio) throws Exception {
        setIdentificador(identificador);
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) throws Exception {
        if(identificador.trim().length() > 3){
            this.identificador = identificador;
        }else{
            throw new Exception("ERROR: el identificador no puede tener menos de 3 caracteres!");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Producto{" + "identificador=" + identificador + ", nombre=" + nombre + ", descripcion=" + descripcion + ", precio=" + precio + '}';
    }
}
