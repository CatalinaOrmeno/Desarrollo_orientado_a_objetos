package Modelo;

/**
 *
 * @author Catalina
 */
public class Figura extends Producto{
    private char material;
    private double altura;

    public Figura() {
    }

    public Figura(char material, double altura, String identificador, String nombre, String descripcion, double precio) throws Exception {
        super(identificador, nombre, descripcion, precio);
        this.material = material;
        this.altura = altura;
    }

    public char getMaterial() {
        return material;
    }

    public void setMaterial(char material) throws Exception {
        this.material = material;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public String toString() {
        return super.toString() + "Figura{" + "material=" + material + ", altura=" + altura + '}';
    }
}
