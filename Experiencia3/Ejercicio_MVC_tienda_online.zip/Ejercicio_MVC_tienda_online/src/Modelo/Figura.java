package Modelo;

/**
 *
 * @author Catalina
 */
public class Figura extends Producto{
    private char material;
    private double altura;

    public Figura() {
    }

    public Figura(char material, double altura, String identificador, String nombre, String descripcion, int precio) throws Exception {
        super(identificador, nombre, descripcion, precio);
        setMaterial(material);
        this.altura = altura;
    }

    public char getMaterial() {
        return material;
    }

    public void setMaterial(char material) throws Exception {
        if(material == 'R' || material == 'r' ||
                material == 'C' || material == 'c' ||
                material == 'P' || material == 'p'){
            this.material = material;
        }else{
            throw new Exception("ERROR: el material solo puede ser: Resina(R/r), Ceramico(C/c) o Plastico(P/p)!");
        }
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    @Override
    public String toString() {
        return super.toString() + "Figura{" + "material=" + material + ", altura=" + altura + '}';
    }
}
