package Controlador;

import Modelo.Figura;
import Modelo.Peluche;
import Modelo.Producto;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Catalina
 */
public class ProductosDAO {
    private List<Producto> productos;

    public ProductosDAO() {
        productos = new ArrayList<>();
    }
    
    public boolean agregar_productos(Producto producto){
        if(buscar_productos(producto.getIdentificador()) == null){
            return productos.add(producto);
        }
        return false;
    }
    
    public Producto buscar_productos(String identificador){
        for (Producto p : productos) {
            if(p.getIdentificador().equalsIgnoreCase(identificador)){
                return p;
            }
        }
        return null;
    }
    
    public boolean modificar_productos(Producto producto){
        if(buscar_productos(producto.getIdentificador()) != null){
            productos.set(productos.indexOf(buscar_productos(producto.getIdentificador())), producto);
            return true;
        }
        return false;
    }
    
    public boolean eliminar_productos(String identificador){
        if(buscar_productos(identificador) != null){
            return productos.remove(buscar_productos(identificador));
        }
        return false;
    }
    
    public List<Producto> listar_productos(){
        return productos;
    }
    
    public int cantidad_productos(){
        return productos.size();
    }
    
    public int cantidad_figuras(){
        int cont = 0;
        for (Producto p : productos) {
            if(p instanceof Figura){
                cont++;
            }
        }
        return cont;
    }
    
    public int cantidad_peluches(){
        int cont = 0;
        for (Producto p : productos) {
            if(p instanceof Peluche){
                cont++;
            }
        }
        return cont;
    }
}
