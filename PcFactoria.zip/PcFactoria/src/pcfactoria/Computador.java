package pcfactoria;

import java.util.Date;
import java.util.HashSet;

/**
 *
 * @author Catalina
 */
public class Computador {
    //REGLAS DE NEGOCIO: estas condiciones se deasrrollan en el mutador(SET-SETTER)
    private String marca; //Lenovo, Samsung
    private char tiene_lector; // S-s = si / N-n = no
    private int disco_duro;
    private double peso;
    private float pantalla;
    private long codigo;
    private Date fecha_armado;
    private boolean camara; // True = Si / False = No

    public Computador(String marca, char tiene_lector, int disco_duro, double peso, float pantalla, long codigo, Date fecha_armado, boolean camara) {
        setMarca(marca);
        setTiene_lector(tiene_lector);
        setDisco_duro(disco_duro);
        setPeso(peso);
        setPantalla(pantalla);
        setCodigo(codigo);
        setFecha_armado(fecha_armado);
        setCamara(camara);
    }

    public Computador() {
    }

    public String getMarca() {
        return marca;
    }

    public char getTiene_lector() {
        return tiene_lector;
    }

    public int getDisco_duro() {
        return disco_duro;
    }

    public double getPeso() {
        return peso;
    }

    public float getPantalla() {
        return pantalla;
    }

    public long getCodigo() {
        return codigo;
    }

    public Date getFecha_armado() {
        return fecha_armado;
    }

    public boolean isCamara() {
        return camara;
    }

    private void setMarca(String marca) {
        if(marca.trim().equalsIgnoreCase("LENOVO") || marca.trim().equalsIgnoreCase("SAMSUNG")){
            this.marca = marca;
        }else{
            System.err.println("Error! marca debe ser lenovo o samsung!");
        }
    }

    public void setTiene_lector(char tiene_lector) {
        this.tiene_lector = tiene_lector;
    }

    public void setDisco_duro(int disco_duro) {
        if(disco_duro>=128 && disco_duro<=2000){
            this.disco_duro = disco_duro;
        }else{
            System.err.println("Error! el disco duro debe estar entre 128 y 2000 GB");
        }
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setPantalla(float pantalla) {
        this.pantalla = pantalla;
    }

    public void setCodigo(long codigo) {
        this.codigo = codigo;
    }

    public void setFecha_armado(Date fecha_armado) {
        this.fecha_armado = fecha_armado;
    }

    public void setCamara(boolean camara) {
        this.camara = camara;
    }

    @Override
    public String toString() {
        return "Computador{" + "marca=" + marca + ", tiene_lector=" + tiene_lector + ", disco_duro=" + disco_duro + ", peso=" + peso + ", pantalla=" + pantalla + ", codigo=" + codigo + ", fecha_armado=" + fecha_armado + ", camara=" + camara + '}';
    }
    
    public void imprimir(){
        System.out.println("Marca: " + marca);
        System.out.println("Tiene lector: " + tiene_lector);
        System.out.println("Disco duro: " + disco_duro + " GB");
        System.out.println("Peso(KG): " + peso);
        System.out.println("Pantalla: " + pantalla);
        System.out.println("Código: " + codigo);
        System.out.println("Fecha de armado: " + fecha_armado);
        System.out.println("Cámara: " + camara);   
    }
    
}
