package pcfactoria;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Catalina
 */
public class PcFactoria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Computador c1 = new Computador();
        
        Computador c2 = new Computador("marquita", 'S', 128, 1.5, 12.5f, 123456789012345L, new Date(), false);
        //c2.imprimir();
    }
    
}
