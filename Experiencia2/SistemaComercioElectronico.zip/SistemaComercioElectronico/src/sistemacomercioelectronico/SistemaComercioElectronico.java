package sistemacomercioelectronico;

import sistemacomercioelectronico.Categorias.Electronico;
import sistemacomercioelectronico.Categorias.Ropa;

/**
 *
 * @author Catalina
 */
public class SistemaComercioElectronico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Carrito carrito = new Carrito();
        Electronico e1 = new Electronico("Sony", 6, "E_1", "Hervidor electrico", 25000);
        Electronico e2 = new Electronico("Samsung", 12, "E_2", "Refrigerador de 2 puertas", 80000);
        Ropa r1 = new Ropa("XL", "Amarilla", "R_1", "Polo amarillo", 15000);
        System.out.println((carrito.agregar_producto(e1)?"El producto a sido agregado exitosamente!" : "El producto ingresado ya se encuentra en la lista!"));
        System.out.println((carrito.agregar_producto(e2)?"El producto a sido agregado exitosamente!" : "El producto ingresado ya se encuentra en la lista!"));
        System.out.println((carrito.agregar_producto(r1)?"El producto a sido agregado exitosamente!" : "El producto ingresado ya se encuentra en la lista!"));
        //carrito.listar_productos();
        e1.extender_garantia(6);
        carrito.listar_productos();
        System.out.println("Total a pagar: $"+ carrito.costo_total());
        System.out.println("Cantidad de electrodomesticos: "+ carrito.cantiad_electrodomensticos());
    }
    
}
