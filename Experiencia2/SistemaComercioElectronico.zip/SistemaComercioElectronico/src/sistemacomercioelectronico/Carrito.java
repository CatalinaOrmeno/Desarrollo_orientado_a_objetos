package sistemacomercioelectronico;

import java.util.ArrayList;
import java.util.List;
import sistemacomercioelectronico.Categorias.Electronico;
import sistemacomercioelectronico.Categorias.Producto;

/**
 *
 * @author Catalina
 */
public class Carrito {
    private List<Producto> productos;

    public Carrito() {
        productos = new ArrayList<>();
    }
    
    public boolean agregar_producto(Producto producto){
        if(buscar_producto(producto.getId_producto())== null){
            return productos.add(producto);
        }
        return false;
    }
    
    public Producto buscar_producto(String id_producto){
        for (Producto p : productos) {
            if(p.getId_producto().equalsIgnoreCase(id_producto)){
                return p;
            }
        }
        return null;
    }
    
    public boolean modificar_producto(Producto nuevos_datos){
        if(buscar_producto(nuevos_datos.getId_producto())!= null){
            productos.set(productos.indexOf(buscar_producto(nuevos_datos.getId_producto())), nuevos_datos);
            return true;
        }
        return false;
    }
    
    public boolean eliminar_producto(Producto producto){
        if(buscar_producto(producto.getId_producto())!= null){
            return productos.remove(producto);
        }
        return false;
    }
    
    public void listar_productos(){
        for (Producto p : productos) {
            p.imprimir();
        }
    }
    
    public int costo_total(){
        int costo_total = 0;
        for (Producto p : productos) {
            costo_total += p.getPrecio();
        }
        return costo_total;
    }
    
    public int cantiad_electrodomensticos(){
        int cont = 0;
        for (Producto p : productos) {
            if(p instanceof Electronico){
                cont ++;
            }
        }
        return cont;
    }
}
