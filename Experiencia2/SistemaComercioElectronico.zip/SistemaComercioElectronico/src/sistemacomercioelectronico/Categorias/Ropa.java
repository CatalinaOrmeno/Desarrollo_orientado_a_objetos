package sistemacomercioelectronico.Categorias;

/**
 *
 * @author Catalina
 */
public class Ropa extends Producto{
    private String talla, color;

    public Ropa() {
    }

    public Ropa(String talla, String color, String id_producto, String nombre, double precio) {
        super(id_producto, nombre, precio);
        this.talla = talla;
        this.color = color;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return super.toString()+"Ropa{" + "talla=" + talla + ", color=" + color + '}';
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Talla: "+talla.toUpperCase());
        System.out.println("Color: "+color+"\n");
    }
    
    public void ajustar_talla(String nueva_talla){
        setTalla(nueva_talla);
    }

    @Override
    public double calcular_descuento(double descuento) {
        if(descuento > super.getPrecio()){
            return 0;
        }
        return (super.getPrecio() - descuento) * (1 - PORCENTAJE_DESCUENTO);
    }
}
