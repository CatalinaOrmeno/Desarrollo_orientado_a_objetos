package sistemacomercioelectronico.Categorias;

/**
 *
 * @author Catalina
 */
public abstract class Producto {
    protected String id_producto,nombre;
    protected double precio;

    public Producto() {
    }

    public Producto(String id_producto, String nombre, double precio) {
        this.id_producto = id_producto;
        this.nombre = nombre;
        this.precio = precio;
    }

    public String getId_producto() {
        return id_producto;
    }

    public void setId_producto(String id_producto) {
        this.id_producto = id_producto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Producto{" + "id_producto=" + id_producto + ", nombre=" + nombre + ", precio=" + precio + '}';
    }
    
    public void imprimir(){
        System.out.println("ID producto: "+ id_producto);
        System.out.println("Nombre: "+ nombre);
        System.out.println("Precio: $"+ precio);
    }
    
    public double calcular_desc(double descuento){
        setPrecio(precio - (precio * (descuento / 100)));
        return precio;
    }
}
