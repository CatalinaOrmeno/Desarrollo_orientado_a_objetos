package sistemacomercioelectronico.Categorias;

/**
 *
 * @author Catalina
 */
public interface IProducto {
    //Ejemplo: constante cuyo valor no puede cambiar en el desarrollo.
    final double PORCENTAJE_DESCUENTO = 0.25;
    
    //Vamos a definir el método de calcular descuento
    public double calcular_descuento(double descuento);
}
