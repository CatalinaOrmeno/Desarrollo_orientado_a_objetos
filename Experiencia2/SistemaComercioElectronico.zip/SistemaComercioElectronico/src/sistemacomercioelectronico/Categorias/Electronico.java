package sistemacomercioelectronico.Categorias;

/**
 *
 * @author Catalina
 */
public class Electronico extends Producto{
    private String marca;
    private int garantia_meses;

    public Electronico() {
    }

    public Electronico(String marca, int garantia_meses, String id_producto, String nombre, double precio) {
        super(id_producto, nombre, precio);
        this.marca = marca;
        this.garantia_meses = garantia_meses;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getGarantia_meses() {
        return garantia_meses;
    }

    public void setGarantia_meses(int garantia_meses) {
        this.garantia_meses = garantia_meses;
    }

    @Override
    public String toString() {
        return super.toString() +"Electronico{" + "marca=" + marca + ", garantia_meses=" + garantia_meses + '}';
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("Marca: "+ marca);
        System.out.println("Garantia: "+ garantia_meses +" meses"+"\n");
    }
    
    public void extender_garantia(int meses_extra){
        setGarantia_meses(garantia_meses + meses_extra);
    }

    @Override
    public double calcular_descuento(double descuento) {
        if(descuento > super.getPrecio()){
            return 0;
        }
        return super.getPrecio() - descuento;
    } 
}
