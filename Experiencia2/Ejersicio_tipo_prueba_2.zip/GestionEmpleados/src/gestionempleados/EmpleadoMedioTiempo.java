package gestionempleados;

import java.util.Date;

/**
 *
 * @author Catalina
 */
public class EmpleadoMedioTiempo extends Empleado{
    private double valor_hora;
    private int horas_trabajadas;

    public EmpleadoMedioTiempo() {
    }

    public EmpleadoMedioTiempo(double valor_hora, int horas_trabajadas, String nombre, Date fecha_contrato, char genero, boolean activo, Departamento departamento) {
        super(nombre, fecha_contrato, genero, activo, departamento);
        setValor_hora(valor_hora);
        this.horas_trabajadas = horas_trabajadas;
    }

    public double getValor_hora() {
        return valor_hora;
    }

    public void setValor_hora(double valor_hora) {
        if(valor_hora > 0){
            this.valor_hora = valor_hora;
        }else{
            System.err.println("ERROR: el valor por hora tiene que ser mayor a 0");
        }
    }

    public int getHoras_trabajadas() {
        return horas_trabajadas;
    }

    public void setHoras_trabajadas(int horas_trabajadas) {
        if(horas_trabajadas >= 0){
            this.horas_trabajadas = horas_trabajadas;
        }else{
            System.err.println("ERROR: la cantidad de horas trabajados no puede ser negativa");
        }
    }

    @Override
    public String toString() {
        return super.toString()+"EmpleadoMedioTiempo{" + "valor_hora=" + valor_hora + ", horas_trabajadas=" + horas_trabajadas + '}';
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("--- Datos salariales ---");
        System.out.println("Valor por hora: $"+valor_hora);
        System.out.println("Horas trabajadas: "+horas_trabajadas+"\n");
    }
    
    @Override
    public double calcular_desc_afp() {
        return valor_hora * horas_trabajadas * PORCENTAJE_AFP;
    }

    @Override
    public double calcular_sueldo_final() {
        return (valor_hora * horas_trabajadas) - calcular_desc_afp();
    }
    
}
