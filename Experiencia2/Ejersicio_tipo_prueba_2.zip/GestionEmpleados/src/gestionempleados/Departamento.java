package gestionempleados;

/**
 *
 * @author Catalina
 */
public class Departamento {
    private String nombre;
    private int codigo;
    private String descripcion;

    public Departamento() {
    }

    public Departamento(String nombre, int codigo, String descripcion) {
        setNombre(nombre);
        setCodigo(codigo);
        setDescripcion(descripcion);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(nombre.trim().length()<=50){
            this.nombre = nombre;
        }else{
            System.err.println("ERROR: el largo del nombre tiene que ser menor o igual a 50 caracteres.");
        }
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        if(codigo > 0){
            this.codigo = codigo;
        }else{
            System.err.println("ERROR: el código tiene que ser positivo");
        }
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        if(descripcion.trim().length()<=200){
            this.descripcion = descripcion;
        }else{
            System.err.println("ERROR: el largo de la descripción tiene que ser menor o igual a 200 caracteres.");
        }
    }

    @Override
    public String toString() {
        return "Departamento{" + "nombre=" + nombre + ", codigo=" + codigo + ", descripcion=" + descripcion + '}';
    }
    
    public void imprimir(){
        System.out.println("Nombre: "+nombre);
        System.out.println("Código: "+codigo);
        System.out.println("Descripción: "+descripcion);
    }
}
