package gestionempleados;

/**
 *
 * @author Catalina
 */
public interface IEmpleado {
    final double PORCENTAJE_AFP = 0.07;
    
    double calcular_desc_afp();
    double calcular_sueldo_final();
}
