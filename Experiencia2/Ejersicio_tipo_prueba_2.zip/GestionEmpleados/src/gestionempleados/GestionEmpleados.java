package gestionempleados;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Catalina
 */
public class GestionEmpleados {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException {
        Departamento departamento = new Departamento("Contabilidad", 1111, "El departamento de contabilidad");
        EmpleadoTiempoCompleto e1 = new EmpleadoTiempoCompleto(550000, "Camilo Sevilla", new Date(), 'm', true, departamento);
        EmpleadoMedioTiempo e2 = new EmpleadoMedioTiempo(10000, 90, "Maria Gonzalez", new Date(), 'f', true, departamento);
        EmpleadoMedioTiempo e3 = new EmpleadoMedioTiempo(5000, 30, "José Ramirez", new Date(), 'f', true, departamento);
        //El siguiente si salta el error de la fecha
        //EmpleadoMedioTiempo empleado_fallido = new EmpleadoMedioTiempo(15000, 30, "José Ramirez", new SimpleDateFormat("dd-MM-y").parse("20-10-24"), 'f', true, departamento);
        EmpleadoMedioTiempo empleado_replicado = new EmpleadoMedioTiempo(20000, 100, "Maria Gonzalez", new Date(), 'f', false, departamento);
        Empresa empresa = new Empresa();
        
        System.out.println( empresa.agregar_empleado(e1)?"Empleado agregado exitosamente!" : "El empleado ya esta registrado en la base de datos");
        System.out.println( empresa.agregar_empleado(e2)?"Empleado agregado exitosamente!" : "El empleado ya esta registrado en la base de datos");
        System.out.println( empresa.agregar_empleado(e3)?"Empleado agregado exitosamente!" : "El empleado ya esta registrado en la base de datos");
        System.out.println( empresa.agregar_empleado(empleado_replicado)?"Empleado agregado exitosamente!" : "El empleado ya esta registrado en la base de datos");
        empresa.listar_empleados();
        System.out.println("Empleados activos: "+empresa.contar_empleados_activos());
        System.out.println("Cantidad de empleados con salario mayor a $400.000: "+empresa.contar_empleados_con_salario_base_mayor_a(400000));
        
        //Calculo de empleado de tiempo completo:
        System.out.println("\n--- Calculo de sueldo liquido ---");
        e1.imprimir();
        System.out.println("Descuento AFP: $"+e1.calcular_desc_afp());
        System.out.println("Sueldo final: $"+e1.calcular_sueldo_final());
        //Calculo de empleado de medio tiempo:
        System.out.println("\n--- Calculo de sueldo liquido ---");
        e2.imprimir();
        System.out.println("Descuento AFP: $"+e2.calcular_desc_afp());
        System.out.println("Sueldo final: $"+e2.calcular_sueldo_final());
        
        /* MENÚ:
        Scanner input = new Scanner(System.in);
        do {            
            System.out.println("--- SISTEMA DE GESTIÓN DE EMPLEADOS ---");
            System.out.println("1. Gestión de empleados");
            System.out.println("2. Estadisticas de la empresa");
            System.out.println("3. Datos salariales");
            System.out.println("4. Salir");
            System.out.print("¿Que area quieres manejar?: ");
            String resp = input.next().trim();
            if(resp.equals("1")){
                resp = input.nextLine();
                System.out.println("--- Gestión de empleados ---");
                System.out.println("1. Agregar empleado");
                System.out.println("2. Buscar empleado");
                System.out.println("3. Actualizar empleado");
                System.out.println("4. Eliminar empleado");
                System.out.println("5. Listar empleados");
                System.out.println("6. Volver a menú principal");
                resp = input.next().trim();
                if(resp.equals("1")){
                    
                }
            }else if(resp.equals("4")){
                System.out.println("Gracias por usar el programa!");
                break;
            }else{
                resp = input.nextLine();
                System.err.println("ERROR: respuesta invalida");
            }
        } while (true);
        */
    }
}
