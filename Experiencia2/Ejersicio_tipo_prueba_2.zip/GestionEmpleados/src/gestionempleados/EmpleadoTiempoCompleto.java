package gestionempleados;

import java.util.Date;

/**
 *
 * @author Catalina
 */
public class EmpleadoTiempoCompleto extends Empleado{
    private double salario_base;

    public EmpleadoTiempoCompleto() {
    }

    public EmpleadoTiempoCompleto(double salario_base, String nombre, Date fecha_contrato, char genero, boolean activo, Departamento departamento) {
        super(nombre, fecha_contrato, genero, activo, departamento);
        setSalario_base(salario_base);
    }

    public double getSalario_base() {
        return salario_base;
    }

    public void setSalario_base(double salario_base) {
        if(salario_base > 0){
            this.salario_base = salario_base;
        }else{
            System.err.println("ERROR: el salario base tiene que ser mayor a 0");
        }
    }

    @Override
    public String toString() {
        return super.toString()+"EmpleadoTiempoCompleto{" + "salario_base=" + salario_base + '}';
    }

    @Override
    public void imprimir() {
        super.imprimir();
        System.out.println("--- Datos salariales ---");
        System.out.println("Salario base: $"+salario_base+"\n");
    }
    
    @Override
    public double calcular_desc_afp() {
        return salario_base * PORCENTAJE_AFP;
    }

    @Override
    public double calcular_sueldo_final() {
        return salario_base - calcular_desc_afp();
    }
    
}
