package gestionempleados;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Catalina
 */
public class Empresa {
    private List<Empleado> empleados;

    public Empresa() {
        empleados = new ArrayList<>();
    }
    
    public boolean agregar_empleado(Empleado empleado){
        if(buscar_empleado(empleado.getNombre()) == null){
            return empleados.add(empleado);
        }
        return false;
    }
    
    public Empleado buscar_empleado(String nombre){
        for (Empleado e : empleados) {
            if(e.getNombre().equalsIgnoreCase(nombre)){
                return e;
            }
        }
        return null;
    }
    
    public boolean actualizar_empleado(Empleado empleado){
        if(buscar_empleado(empleado.getNombre()) != null){
            empleados.set(empleados.indexOf(buscar_empleado(empleado.getNombre())), empleado);
            return true;
        }
        return false;
    }
    
    public boolean eliminar_empleado(String nombre){
        if(buscar_empleado(nombre) == null){
            return empleados.remove(buscar_empleado(nombre));
        }
        return false;
    }
    
    public void listar_empleados(){
        for (Empleado e : empleados) {
            e.imprimir();
        }
    }
    
    public int contar_empleados_activos(){
        int contador = 0;
        for (Empleado e : empleados) {
            if(e.isActivo()){
                contador ++;
            }
        }
        return contador;
    }
    
    public int contar_empleados_con_salario_base_mayor_a(double salario){
        int contador = 0;
        for (Empleado e : empleados) {
            if(e instanceof EmpleadoTiempoCompleto){
                EmpleadoTiempoCompleto empleado = (EmpleadoTiempoCompleto) e;
                if(empleado.getSalario_base() > salario){
                    contador ++;
                }
            }
        }
        return contador;
    }
}
