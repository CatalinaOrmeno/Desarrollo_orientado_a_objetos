package gestionempleados;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Catalina
 */
public abstract class Empleado implements IEmpleado{
    protected String nombre;
    protected Date fecha_contrato;
    protected char genero;
    protected boolean activo;
    protected Departamento departamento;

    public Empleado() {
    }

    public Empleado(String nombre, Date fecha_contrato, char genero, boolean activo, Departamento departamento) {
        setNombre(nombre);
        setFecha_contrato(fecha_contrato);
        setGenero(genero);
        this.activo = activo;
        this.departamento = departamento;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(nombre.trim().length()<=100){
            this.nombre = nombre;
        }else{
            System.err.println("ERROR: el largo del nombre  tiene que ser menor o igual a 100 caracteres.");
        }
    }

    public Date getFecha_contrato() {
        return fecha_contrato;
    }

    public void setFecha_contrato(Date fecha_contrato) {
        if(fecha_contrato.after(new Date())){
            System.err.println("ERROR: el empleado no puede haber sido contatado en una fecha futura");
        }else{
            this.fecha_contrato = fecha_contrato;
        }
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        if(genero == 'M'||genero == 'm'||
                genero == 'F'||genero == 'f'||
                genero == 'O'||genero == 'o'){
            this.genero = genero;
        }else{
            System.err.println("ERROR: el género puede ser: Femenino(F/f), Masculino(M/m) u Otro(O/o)");
        }
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    @Override
    public String toString() {
        return "Empleado{" + "nombre=" + nombre + ", fecha_contrato=" + fecha_contrato + ", genero=" + genero + ", activo=" + activo + ", departamento=" + departamento + '}';
    }

    public void imprimir(){
        System.out.println("--- Datos ---");
        System.out.println("Nombre: "+nombre);
        System.out.println("Fecha de contrato: "+new SimpleDateFormat("dd-MM-y").format(fecha_contrato));
        System.out.print("Género: ");
        if(genero == 'M'||genero == 'm'){
            System.out.println("Masculino");
        }else if(genero == 'F'||genero == 'f'){
            System.out.println("Femenino");
        }else{
            System.out.println("Otro");
        }
        System.out.println( activo ? "Esta activo" : "Esta inactivo");
        System.out.println("--- Departamento ---");
        departamento.imprimir();
    }
}
