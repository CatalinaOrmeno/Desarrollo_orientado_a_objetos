package dentalife;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alambrito
 */
public class Clinica {
    
    //esta clase va a manejar a los pacientes:
    //1. Se debe declarar y solo declara una lista:
    private List<Paciente> pacientes;
    
    //2. Debemos inicializar la lista, pero a través del constructor:
    public Clinica() {
        pacientes = new ArrayList<>();
    }
    
    //3. Ahora debemos crear un CRUD (Create, Read, Update, Delete)
    public boolean agregarPaciente(Paciente paciente){
        if( buscarPaciente(paciente.getRut()) == null ){
            return pacientes.add(paciente);
        }else{
            return false;
        }
    }
    
    public Paciente buscarPaciente(int rut){
        //fore + tab:
        for (Paciente p : pacientes) {
            if(rut == p.getRut() ){
                return p;
            }
        }
        return null;
    }
    
    public boolean actualizarPaciente(Paciente paciente_actualizado){
        if ( buscarPaciente(paciente_actualizado.getRut())!=null ) {
            for (Paciente p : pacientes) {
                if (p.getRut()==paciente_actualizado.getRut() ) {
                    int posicion = pacientes.indexOf(p);
                    pacientes.set(posicion, paciente_actualizado);
                    return true;
                }
            }
        }
        return false;
    }
    
    public boolean eliminarPaciente(int rut){
        if ( buscarPaciente(rut)!=null ) {
            for (Paciente p : pacientes) {
                if (p.getRut()==rut) {
                    return pacientes.remove(p);
                }
            }
        }
        return false;
    }
    
    public void listarPacientes(){
        System.out.println("LISTA DE PACIENTES");
        for (Paciente p : pacientes) {
            p.imprimir();
            System.out.println("");
        }
    }
    
}
