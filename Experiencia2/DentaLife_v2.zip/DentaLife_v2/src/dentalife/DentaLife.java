package dentalife;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alambrito
 */
public class DentaLife {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //aquí va el desarrollo:
        
        //Cómo se crea una colección:
        //1. aquí solamente declaramos la lista:
        /*List<String> nombres = new ArrayList<>();
        nombres.add("Pedro");
        nombres.add(0, "Juan");
        nombres.clear();
        nombres.add("Maria");
        nombres.add("Maria");
        nombres.remove("Maria");
        nombres.remove(0);
        System.out.println( (nombres.isEmpty() ? "vacia" : "tiene algo") );
        System.out.println( nombres.size() );
        
        nombres.add("Guaton Loyola");
        nombres.add("la conzentida");
        System.out.println( nombres.get(0) );
        
        System.out.println(nombres);*/
        
        //VAMOS A PROBAR NUESTROS MÉTODOS:
        Paciente p1 = new Paciente(16666666, "Diablo", true);
        Paciente p2 = new Paciente(17777777, "Dios", false);
        Paciente p3 = new Paciente(18888888, "Gabriel", false);
        Paciente p4 = new Paciente(16666666, "Pedro", false);
        
        //VAMOS A CREAR LA LISTA:
        Clinica c = new Clinica();
        
        //AHORA USAMOS LOS MÉTODOS DE LA LISTA:
        System.out.println( (c.agregarPaciente(p1) ? "AGREGADO" : "NO SE AGREGÓ, RUT YA EXISTE!") );
        System.out.println( (c.agregarPaciente(p2) ? "AGREGADO" : "NO SE AGREGÓ, RUT YA EXISTE!") );
        System.out.println( (c.agregarPaciente(p3) ? "AGREGADO" : "NO SE AGREGÓ, RUT YA EXISTE!") );
        System.out.println( (c.actualizarPaciente(p4) ? "MODIFICADO" : "NO SE MODIFICO, NO EXISTE EL RUT!") );
        System.out.println( c.eliminarPaciente(17777777) ? "ELIMINADO!" : "NO ELIMINADO, RUT NO EXISTE!" );
        
        //c.listarPacientes();
        System.out.println( c.buscarPaciente(18888888) );
    }
    
}
