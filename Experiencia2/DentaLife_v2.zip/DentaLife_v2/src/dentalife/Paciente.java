package dentalife;

/**
 *
 * @author Alambrito
 */
public class Paciente {
    
    private int rut;
    private String nombre;
    private boolean tiene_seguro;

    public Paciente() {
    }

    public Paciente(int rut, String nombre, boolean tiene_seguro) {
        this.rut = rut;
        this.nombre = nombre;
        this.tiene_seguro = tiene_seguro;
    }

    public int getRut() {
        return rut;
    }

    public void setRut(int rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isTiene_seguro() {
        return tiene_seguro;
    }

    public void setTiene_seguro(boolean tiene_seguro) {
        this.tiene_seguro = tiene_seguro;
    }

    @Override
    public String toString() {
        return "Paciente{" + "rut=" + rut + ", nombre=" + nombre + ", tiene_seguro=" + tiene_seguro + '}';
    }
    
    public void imprimir(){
        System.out.println("RUT: " + rut);
        System.out.println("NOMBRE: " + nombre);
        System.out.println(tiene_seguro ? "TIENE SEGURO: SI" : "TIENE SEGURO NO");
    }
}
