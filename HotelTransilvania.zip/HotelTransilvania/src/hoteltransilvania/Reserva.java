package hoteltransilvania;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Catalina
 */
public class Reserva {
    private int id_reserva;
    private Date fecha_inicio, fecha_fin;
    private Cliente cliente;
    private Habitacion habitacion;

    public Reserva() {
    }

    public Reserva(int id_reserva, Date fecha_inicio, Date fecha_fin, Cliente cliente, Habitacion habitacion) {
        this.id_reserva = id_reserva;
        this.fecha_inicio = fecha_inicio;
        this.fecha_fin = fecha_fin;
        this.cliente = cliente;
        this.habitacion = habitacion;
    }

    public int getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(int id_reserva) {
        this.id_reserva = id_reserva;
    }

    public Date getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(Date fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public Date getFecha_fin() {
        return fecha_fin;
    }

    public void setFecha_fin(Date fecha_fin) {
        this.fecha_fin = fecha_fin;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Habitacion getHabitacion() {
        return habitacion;
    }

    public void setHabitacion(Habitacion habitacion) {
        this.habitacion = habitacion;
    }

    @Override
    public String toString() {
        return "Reserva{" + "id_reserva=" + id_reserva + ", fecha_inicio=" + fecha_inicio + ", fecha_fin=" + fecha_fin + ", cliente=" + cliente + ", habitacion=" + habitacion + '}';
    }
    
    public void imprimir(){
        System.out.println("Id reserva: "+ id_reserva);
        System.out.println("Fecha inicio: "+ new SimpleDateFormat("dd-MM-y").format(fecha_inicio));
        System.out.println("Fecha fin: "+ new SimpleDateFormat("dd-MM-y").format(fecha_fin));
        cliente.imprimir();
        habitacion.imprimir();
    }
    
    public double calcular_costo_total(){
        int noches = fecha_fin.compareTo(fecha_inicio);
        return habitacion.getPrecio() * noches;
    }
    
    public boolean confirmar_reserva(){
        if(habitacion.isDisponible())
    }
}
