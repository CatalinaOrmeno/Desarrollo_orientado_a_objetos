package hoteltransilvania;

/**
 *
 * @author Catalina
 */
public class Cliente {
    private String nombre,documento_identidad,direccion;
    private int telefono;
    private char genero;

    public Cliente() {
    }

    public Cliente(String nombre, String documento_identidad, String direccion, int telefono, char genero) {
        setNombre(nombre);
        this.documento_identidad = documento_identidad;
        this.direccion = direccion;
        setTelefono(telefono);
        setGenero(genero);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if(nombre.trim().length()>=3){
            this.nombre = nombre;
        }else{
            System.err.println("ERROR: el nombre debetener minimo 3 caracteres.");
        }
    }

    public String getDocumento_identidad() {
        return documento_identidad;
    }

    public void setDocumento_identidad(String documento_identidad) {
        this.documento_identidad = documento_identidad;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        //String.valueOf(X): sirve para tranformar cualquier objeto/variable a String.
        if(String.valueOf(telefono).length()==9){
            this.telefono = telefono;
        }else{
            System.err.println("ERROR: el teléfono debe tener 9 digitos.");
        }
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        if(genero=='f'||genero=='F'||genero=='m'||genero=='M'){
            this.genero = genero;
        }else{
            System.err.println("ERROR: el genero tiene que ser femenino(F/f) o masculino(M/m)");
        }
    }

    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", documento_identidad=" + documento_identidad + ", direccion=" + direccion + ", telefono=" + telefono + ", genero=" + genero + '}';
    }
    
    public void imprimir(){
        System.out.println("Nombre: "+ nombre);
        System.out.println("Documento identidad: "+ documento_identidad);
        System.out.println("Dirección: "+ direccion);
        System.out.println("Telédono: "+ telefono);
        if(genero=='f'||genero=='F'){
            System.out.println("Género: femenino");
        }else{
            System.out.println("Género: masculino");
        }
    }
    
    public void actualizar_datos_contacto(String nueva_direccion, int nuevo_telefono){
        setDireccion(nueva_direccion);
        setTelefono(nuevo_telefono);
        System.out.println("Dirección y teléfono actualizado con éxito!");
    }
}
