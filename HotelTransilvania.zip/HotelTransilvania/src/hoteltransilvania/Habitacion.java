package hoteltransilvania;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Catalina
 */
public class Habitacion {
    private int numero;
    private String tipo;
    private double precio;
    private boolean disponible;
    private Date fecha_ultima_limpieza;

    public Habitacion() {
    }

    public Habitacion(int numero, String tipo, double precio, boolean disponible, Date fecha_ultima_limpieza) {
        this.numero = numero;
        setTipo(tipo);
        this.precio = precio;
        this.disponible = disponible;
        setFecha_ultima_limpieza(fecha_ultima_limpieza);
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        if(tipo.trim().equalsIgnoreCase("simple")||
           tipo.trim().equalsIgnoreCase("Doble")||
           tipo.trim().equalsIgnoreCase("Suite")){
            this.tipo = tipo;
        }else{
            System.err.println("ERROR: el tipo tiene que ser simple, doble o suite");
        }
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public Date getFecha_ultima_limpieza() {
        return fecha_ultima_limpieza;
    }

    public void setFecha_ultima_limpieza(Date fecha_ultima_limpieza) {
        this.fecha_ultima_limpieza = fecha_ultima_limpieza;
    }

    @Override
    public String toString() {
        return "Habitacion{" + "numero=" + numero + ", tipo=" + tipo + ", precio=" + precio + ", disponible=" + disponible + ", fecha_ultima_limpieza=" + fecha_ultima_limpieza + '}';
    }
    
    public void imprimir() {
        System.out.println("Número: "+ numero);
        System.out.println("Tipo: "+ tipo);
        System.out.println("Precio: "+ precio);
        /*if(disponible){
            System.out.println("Disponible");
        }else{
            System.out.println("No disponible");
        }
        La forma resumida de hacer eso es de la siguiente forma:*/
        System.out.println(disponible ? "Disponible" : "No disponible");
        /*
        ? = si es verdadero
        : = si no es verdadero
        Solo sirve para booleanos*/
        System.out.println(new SimpleDateFormat("dd-MM-y").format(fecha_ultima_limpieza));
    }
    
    public void asignar_disponibilidad(boolean estado){
        if(estado){
            this.disponible = false;
            System.out.println("La habitación se acaba de ocupar");
        }else{
            this.disponible = true;
            System.out.println("La habitación ahora esta disponible");
        }
    }
    
    public void actualizar_precio(double nuevo_precio){
        setPrecio(nuevo_precio);
        System.out.println("Precio actualizado a "+ nuevo_precio +" con éxito!");
    }
}
